var searchData=
[
  ['addgroup_5fop',['ADDGROUP_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca30f53d46265f83a2b0a14d6486a450d5',1,'ops.h']]],
  ['aggiorna',['aggiorna',['../chatty_8c.html#aad2eba9dcce98b4a5d1ab4b1cae9a527',1,'aggiorna(fd_set *set, int max):&#160;chatty.c'],['../chatty_8h.html#aad2eba9dcce98b4a5d1ab4b1cae9a527',1,'aggiorna(fd_set *set, int max):&#160;chatty.c']]],
  ['array_5fstruct',['array_struct',['../structarray__struct.html',1,'']]]
];

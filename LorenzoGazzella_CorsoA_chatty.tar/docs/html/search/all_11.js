var searchData=
[
  ['unregister_5fop',['unregister_op',['../gestione_richieste_8c.html#a81614c50af29bdf3938aa45aec62d139',1,'unregister_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#a81614c50af29bdf3938aa45aec62d139',1,'unregister_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cabc2ab44946aad99a4cda3f0e4abb5b5a',1,'UNREGISTER_OP():&#160;ops.h']]],
  ['usrlist_5fop',['usrlist_op',['../gestione_richieste_8c.html#aed4f52e3a3c624d8f7f7fc734289f5c9',1,'usrlist_op(long fd, message_t m, int atomica):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#aed4f52e3a3c624d8f7f7fc734289f5c9',1,'usrlist_op(long fd, message_t m, int atomica):&#160;gestioneRichieste.c'],['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca76c5f8cf5dd046fbfe3f0b6a7bce8e90',1,'USRLIST_OP():&#160;ops.h']]],
  ['utente_5fconnesso',['utente_connesso',['../structutente__connesso.html',1,'']]],
  ['utility_2eh',['utility.h',['../utility_8h.html',1,'']]]
];

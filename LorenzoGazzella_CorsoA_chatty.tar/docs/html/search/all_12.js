var searchData=
[
  ['vuota',['vuota',['../coda_circolare_8c.html#a203243ec9f454ade45b3a64b4bb11819',1,'vuota(coda_circolare_s *c):&#160;codaCircolare.c'],['../coda_circolare_8h.html#a203243ec9f454ade45b3a64b4bb11819',1,'vuota(coda_circolare_s *c):&#160;codaCircolare.c']]]
];

var searchData=
[
  ['freeconfig',['FreeConfig',['../parser_8c.html#a12ca67852f959e9d4a4cfee613c06cd6',1,'FreeConfig(config *configs):&#160;parser.c'],['../parser_8h.html#a12ca67852f959e9d4a4cfee613c06cd6',1,'FreeConfig(config *configs):&#160;parser.c']]]
];

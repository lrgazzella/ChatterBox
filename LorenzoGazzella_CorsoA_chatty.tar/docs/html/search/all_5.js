var searchData=
[
  ['gestionerichieste_2ec',['gestioneRichieste.c',['../gestione_richieste_8c.html',1,'']]],
  ['gestionerichieste_2eh',['gestioneRichieste.h',['../gestione_richieste_8h.html',1,'']]],
  ['getfile_5fop',['GETFILE_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cadb9dcac2886dea585d6851db2a02de4b',1,'GETFILE_OP():&#160;ops.h'],['../gestione_richieste_8c.html#adb730bea65801751de444bbb5125c510',1,'getfile_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#adb730bea65801751de444bbb5125c510',1,'getfile_op(long fd, message_t m):&#160;gestioneRichieste.c']]],
  ['getonlyfilename',['getOnlyFileName',['../gestione_richieste_8c.html#a46f5335fac8b81da30af7aaa196beea1',1,'gestioneRichieste.c']]],
  ['getposizionelibera',['getPosizioneLibera',['../gestione_richieste_8c.html#a7e05b770e237a58c677fde0a96aff694',1,'gestioneRichieste.c']]],
  ['getprevmsgs_5fop',['GETPREVMSGS_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cad40f98fc799cf8b6a8dc25c90464a809',1,'GETPREVMSGS_OP():&#160;ops.h'],['../gestione_richieste_8c.html#af861d94ca1c51d1e273d1103b1367bf1',1,'getprevmsgs_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#af861d94ca1c51d1e273d1103b1367bf1',1,'getprevmsgs_op(long fd, message_t m):&#160;gestioneRichieste.c']]],
  ['getusrfd',['getUsrFd',['../gestione_richieste_8c.html#a8e3c0ed150e76c0c8ee0a7d49da72c70',1,'gestioneRichieste.c']]],
  ['getusrnickname',['getUsrNickname',['../gestione_richieste_8c.html#a063bf005b990deb8193ae41b56a4955a',1,'gestioneRichieste.c']]]
];

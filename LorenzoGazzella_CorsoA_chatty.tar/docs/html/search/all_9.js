var searchData=
[
  ['lung',['lung',['../coda_circolare_8c.html#a34356c3f593b296eae81cc187b52ef05',1,'lung(coda_circolare_s *c):&#160;codaCircolare.c'],['../coda_circolare_8h.html#a34356c3f593b296eae81cc187b52ef05',1,'lung(coda_circolare_s *c):&#160;codaCircolare.c']]]
];

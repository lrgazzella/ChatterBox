var searchData=
[
  ['makeconfig',['makeConfig',['../parser_8c.html#a9f20eaee0fb4e98e3d9f708a1b45e3e1',1,'makeConfig(char *parametro, char *value, config *configs):&#160;parser.c'],['../parser_8h.html#a9f20eaee0fb4e98e3d9f708a1b45e3e1',1,'makeConfig(char *parametro, char *value, config *configs):&#160;parser.c']]],
  ['makelistusr',['makeListUsr',['../gestione_richieste_8c.html#aea85560fdb24ac34b39c6014c25b5ab2',1,'gestioneRichieste.c']]],
  ['message_2eh',['message.h',['../message_8h.html',1,'']]],
  ['message_5fdata_5fhdr_5ft',['message_data_hdr_t',['../structmessage__data__hdr__t.html',1,'']]],
  ['message_5fdata_5ft',['message_data_t',['../structmessage__data__t.html',1,'']]],
  ['message_5fhdr_5ft',['message_hdr_t',['../structmessage__hdr__t.html',1,'']]],
  ['message_5ft',['message_t',['../structmessage__t.html',1,'']]],
  ['messaggio',['messaggio',['../structmessaggio.html',1,'']]]
];

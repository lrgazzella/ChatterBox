var searchData=
[
  ['op_5fok',['OP_OK',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cacc156be86a1cb4bfc0e21d8c72e4971c',1,'ops.h']]],
  ['op_5ft',['op_t',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44c',1,'ops.h']]],
  ['openconnection',['openConnection',['../connections_8c.html#a93ad31c416b2e2055827e5f684e89daf',1,'openConnection(char *path, unsigned int ntimes, unsigned int secs):&#160;connections.c'],['../connections_8h.html#a93ad31c416b2e2055827e5f684e89daf',1,'openConnection(char *path, unsigned int ntimes, unsigned int secs):&#160;connections.c']]],
  ['operation_5ft',['operation_t',['../structoperation__t.html',1,'']]],
  ['ops_2eh',['ops.h',['../ops_8h.html',1,'']]]
];

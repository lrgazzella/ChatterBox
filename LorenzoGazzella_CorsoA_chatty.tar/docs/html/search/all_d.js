var searchData=
[
  ['parse',['parse',['../parser_8c.html#a162fd2cd54e4eaa4175e98f87e776398',1,'parse(char *nomeFile, config *configs):&#160;parser.c'],['../parser_8h.html#a162fd2cd54e4eaa4175e98f87e776398',1,'parse(char *nomeFile, config *configs):&#160;parser.c']]],
  ['parser_2ec',['parser.c',['../parser_8c.html',1,'']]],
  ['parser_2eh',['parser.h',['../parser_8h.html',1,'']]],
  ['postfile_5fop',['POSTFILE_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44caf2b9ae66799c6fdfc938b69f49c9d4e4',1,'POSTFILE_OP():&#160;ops.h'],['../gestione_richieste_8c.html#a7b0c5d59733a6f35eb9d60f1f7019c31',1,'postfile_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#a7b0c5d59733a6f35eb9d60f1f7019c31',1,'postfile_op(long fd, message_t m):&#160;gestioneRichieste.c']]],
  ['posttxt_5fop',['POSTTXT_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44ca87576ba07c1cfb86b898b212bf927e3b',1,'POSTTXT_OP():&#160;ops.h'],['../gestione_richieste_8c.html#a0e28c89434bfa2111b1ad2bae0dfbbdd',1,'posttxt_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#a0e28c89434bfa2111b1ad2bae0dfbbdd',1,'posttxt_op(long fd, message_t m):&#160;gestioneRichieste.c']]],
  ['posttxtall_5fop',['POSTTXTALL_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cad8bffd524142ec0c418a426344387282',1,'POSTTXTALL_OP():&#160;ops.h'],['../gestione_richieste_8c.html#a3b26ca960f1032ffec7b5f14a5a011a5',1,'posttxtall_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#a3b26ca960f1032ffec7b5f14a5a011a5',1,'posttxtall_op(long fd, message_t m):&#160;gestioneRichieste.c']]],
  ['printrisop',['printRisOP',['../chatty_8c.html#a0e499099f562e203205fc3a172ce7351',1,'printRisOP(message_t m, int ok):&#160;chatty.c'],['../chatty_8h.html#a0e499099f562e203205fc3a172ce7351',1,'printRisOP(message_t m, int ok):&#160;chatty.c']]]
];

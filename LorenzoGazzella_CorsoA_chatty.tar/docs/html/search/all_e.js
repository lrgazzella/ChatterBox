var searchData=
[
  ['queue',['Queue',['../struct_queue.html',1,'']]]
];

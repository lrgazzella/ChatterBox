var searchData=
[
  ['readdata',['readData',['../connections_8c.html#acf5cb8379636265d11a008d6aa94dc30',1,'readData(long fd, message_data_t *data):&#160;connections.c'],['../connections_8h.html#acf5cb8379636265d11a008d6aa94dc30',1,'readData(long fd, message_data_t *data):&#160;connections.c']]],
  ['readheader',['readHeader',['../connections_8c.html#a166a9f07b57f9684fc9e97863d97ff03',1,'readHeader(long fd, message_hdr_t *hdr):&#160;connections.c'],['../connections_8h.html#a2a15cc3debfd6700ea0f40a198c55c85',1,'readHeader(long connfd, message_hdr_t *hdr):&#160;connections.c']]],
  ['readmsg',['readMsg',['../connections_8c.html#a2fc6b845d44636fb241a848e58c83420',1,'readMsg(long fd, message_t *msg):&#160;connections.c'],['../connections_8h.html#a2fc6b845d44636fb241a848e58c83420',1,'readMsg(long fd, message_t *msg):&#160;connections.c']]],
  ['register_5fop',['register_op',['../gestione_richieste_8c.html#a25c2822a5b02b73d5423615ed1c06f20',1,'register_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#a25c2822a5b02b73d5423615ed1c06f20',1,'register_op(long fd, message_t m):&#160;gestioneRichieste.c']]],
  ['registrato',['registrato',['../gestione_richieste_8c.html#aed6092ef717047485c83a3abe299d1b5',1,'gestioneRichieste.c']]],
  ['removespaces',['RemoveSpaces',['../parser_8c.html#aa0e8ffda70f1a72400c8f0662b8c003a',1,'RemoveSpaces(char *source):&#160;parser.c'],['../parser_8h.html#aa0e8ffda70f1a72400c8f0662b8c003a',1,'RemoveSpaces(char *source):&#160;parser.c']]]
];

var searchData=
[
  ['coda_5fcircolare',['coda_circolare',['../structcoda__circolare.html',1,'']]],
  ['coda_5fcircolare_5fiteratore',['coda_circolare_iteratore',['../structcoda__circolare__iteratore.html',1,'']]],
  ['config_5fs',['config_s',['../structconfig__s.html',1,'']]],
  ['connessi',['connessi',['../structconnessi.html',1,'']]]
];

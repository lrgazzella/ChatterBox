var searchData=
[
  ['stat_5fstruct',['stat_struct',['../structstat__struct.html',1,'']]],
  ['statistics',['statistics',['../structstatistics.html',1,'']]]
];

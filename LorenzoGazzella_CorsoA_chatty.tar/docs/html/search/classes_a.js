var searchData=
[
  ['utente_5fconnesso',['utente_connesso',['../structutente__connesso.html',1,'']]]
];

var searchData=
[
  ['getfile_5fop',['GETFILE_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cadb9dcac2886dea585d6851db2a02de4b',1,'ops.h']]],
  ['getprevmsgs_5fop',['GETPREVMSGS_OP',['../ops_8h.html#ac6fa1b34da8872e34c2936391332f44cad40f98fc799cf8b6a8dc25c90464a809',1,'ops.h']]]
];

var searchData=
[
  ['gestionerichieste_2ec',['gestioneRichieste.c',['../gestione_richieste_8c.html',1,'']]],
  ['gestionerichieste_2eh',['gestioneRichieste.h',['../gestione_richieste_8h.html',1,'']]]
];

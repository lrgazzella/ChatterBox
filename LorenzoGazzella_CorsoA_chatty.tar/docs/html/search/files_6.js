var searchData=
[
  ['stats_2eh',['stats.h',['../stats_8h.html',1,'']]],
  ['strutturecondivise_2eh',['struttureCondivise.h',['../strutture_condivise_8h.html',1,'']]]
];

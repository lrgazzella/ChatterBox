var searchData=
[
  ['aggiorna',['aggiorna',['../chatty_8c.html#aad2eba9dcce98b4a5d1ab4b1cae9a527',1,'aggiorna(fd_set *set, int max):&#160;chatty.c'],['../chatty_8h.html#aad2eba9dcce98b4a5d1ab4b1cae9a527',1,'aggiorna(fd_set *set, int max):&#160;chatty.c']]]
];

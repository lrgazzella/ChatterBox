var searchData=
[
  ['check',['check',['../parser_8c.html#a1eb5f0ae6982141a59b0e8d7c7bfcd1d',1,'check(config *configs):&#160;parser.c'],['../parser_8h.html#a1eb5f0ae6982141a59b0e8d7c7bfcd1d',1,'check(config *configs):&#160;parser.c']]],
  ['cleanupconfigurazione',['cleanupConfigurazione',['../chatty_8c.html#a31218041afb760a2d455019b7e5a978e',1,'cleanupConfigurazione():&#160;chatty.c'],['../chatty_8h.html#a31218041afb760a2d455019b7e5a978e',1,'cleanupConfigurazione():&#160;chatty.c']]],
  ['cleanupconnessi',['cleanupConnessi',['../chatty_8c.html#a212ca8f9d5789c4482757ca3959667ef',1,'cleanupConnessi():&#160;chatty.c'],['../chatty_8h.html#a212ca8f9d5789c4482757ca3959667ef',1,'cleanupConnessi():&#160;chatty.c']]],
  ['cleanupnsock',['cleanupNSock',['../chatty_8c.html#ab480aa59ec403d489123a3e6002477ee',1,'cleanupNSock():&#160;chatty.c'],['../chatty_8h.html#ab480aa59ec403d489123a3e6002477ee',1,'cleanupNSock():&#160;chatty.c']]],
  ['cleanuppipe',['cleanupPipe',['../chatty_8c.html#a3fe5b3e9c7a25aa943e2d51c049776d4',1,'cleanupPipe():&#160;chatty.c'],['../chatty_8h.html#a3fe5b3e9c7a25aa943e2d51c049776d4',1,'cleanupPipe():&#160;chatty.c']]],
  ['cleanupregistrati',['cleanupRegistrati',['../chatty_8c.html#ae4243c2520358b625c0aff9c0a4243b4',1,'cleanupRegistrati():&#160;chatty.c'],['../chatty_8h.html#ae4243c2520358b625c0aff9c0a4243b4',1,'cleanupRegistrati():&#160;chatty.c']]],
  ['cleanuprichieste',['cleanupRichieste',['../chatty_8c.html#a2e1ae9ecb3dcef089d578627891ef20a',1,'cleanupRichieste():&#160;chatty.c'],['../chatty_8h.html#a2e1ae9ecb3dcef089d578627891ef20a',1,'cleanupRichieste():&#160;chatty.c']]],
  ['cleanupstat',['cleanupStat',['../chatty_8c.html#a6896c6367d89aad456d07321e933a6c0',1,'cleanupStat():&#160;chatty.c'],['../chatty_8h.html#a6896c6367d89aad456d07321e933a6c0',1,'cleanupStat():&#160;chatty.c']]],
  ['cleanupthreadid',['cleanupThreadId',['../chatty_8c.html#a5190ec49d24282426465e3731a34c20f',1,'cleanupThreadId():&#160;chatty.c'],['../chatty_8h.html#a5190ec49d24282426465e3731a34c20f',1,'cleanupThreadId():&#160;chatty.c']]],
  ['connect_5fop',['connect_op',['../gestione_richieste_8c.html#a379adb31da260c88051f5b11d0a9a6d6',1,'connect_op(long fd, message_t m, int atomica):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#a379adb31da260c88051f5b11d0a9a6d6',1,'connect_op(long fd, message_t m, int atomica):&#160;gestioneRichieste.c']]],
  ['copymessage',['copyMessage',['../gestione_richieste_8c.html#aad5e379113758e746716a81727902636',1,'gestioneRichieste.c']]],
  ['createsocket',['createSocket',['../chatty_8c.html#a5ece610682861d1713357ebe3d61997f',1,'createSocket():&#160;chatty.c'],['../chatty_8h.html#a5ece610682861d1713357ebe3d61997f',1,'createSocket():&#160;chatty.c']]]
];

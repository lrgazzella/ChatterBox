var searchData=
[
  ['disconnect_5fop',['disconnect_op',['../gestione_richieste_8c.html#acc40e1f89d52de70e54517e41ed6793e',1,'disconnect_op(long fd):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#acc40e1f89d52de70e54517e41ed6793e',1,'disconnect_op(long fd):&#160;gestioneRichieste.c']]]
];

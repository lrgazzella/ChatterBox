var searchData=
[
  ['elimina',['elimina',['../coda_circolare_8c.html#a4e72570a01238969106228671410b610',1,'elimina(coda_circolare_s *c):&#160;codaCircolare.c'],['../coda_circolare_8h.html#a4e72570a01238969106228671410b610',1,'elimina(coda_circolare_s *c):&#160;codaCircolare.c']]],
  ['eliminacoda',['eliminaCoda',['../coda_circolare_8c.html#a39c310b2bab565bf78327f37fa528601',1,'eliminaCoda(coda_circolare_s *c):&#160;codaCircolare.c'],['../coda_circolare_8h.html#a39c310b2bab565bf78327f37fa528601',1,'eliminaCoda(coda_circolare_s *c):&#160;codaCircolare.c']]],
  ['eliminaiteratore',['eliminaIteratore',['../coda_circolare_8c.html#a268d061db59d4538e4052855f17f0aa1',1,'eliminaIteratore(coda_circolare_iteratore_s *i):&#160;codaCircolare.c'],['../coda_circolare_8h.html#a268d061db59d4538e4052855f17f0aa1',1,'eliminaIteratore(coda_circolare_iteratore_s *i):&#160;codaCircolare.c']]]
];

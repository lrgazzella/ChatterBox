var searchData=
[
  ['makeconfig',['makeConfig',['../parser_8c.html#a9f20eaee0fb4e98e3d9f708a1b45e3e1',1,'makeConfig(char *parametro, char *value, config *configs):&#160;parser.c'],['../parser_8h.html#a9f20eaee0fb4e98e3d9f708a1b45e3e1',1,'makeConfig(char *parametro, char *value, config *configs):&#160;parser.c']]],
  ['makelistusr',['makeListUsr',['../gestione_richieste_8c.html#aea85560fdb24ac34b39c6014c25b5ab2',1,'gestioneRichieste.c']]]
];

var searchData=
[
  ['next',['next',['../coda_circolare_8c.html#a5ede754a8f6f307bc69e6aa52cad855a',1,'next(coda_circolare_iteratore_s *i):&#160;codaCircolare.c'],['../coda_circolare_8h.html#a5ede754a8f6f307bc69e6aa52cad855a',1,'next(coda_circolare_iteratore_s *i):&#160;codaCircolare.c']]]
];

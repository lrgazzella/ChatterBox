var searchData=
[
  ['senddata',['sendData',['../connections_8c.html#aa7805c42a47eb013344c0ceb6b3533e8',1,'sendData(long fd, message_data_t *data):&#160;connections.c'],['../connections_8h.html#a7812cf59eeeaa63ce7d7b9ce93125462',1,'sendData(long fd, message_data_t *msg):&#160;connections.c']]],
  ['sendheader',['sendHeader',['../connections_8c.html#a76519996d7c1c002a8214e8ba40af51c',1,'sendHeader(long fd, message_hdr_t *hdr):&#160;connections.c'],['../connections_8h.html#a1a3f1d447f26575379802386e4cb1587',1,'sendHeader(long fd, message_hdr_t *msg):&#160;connections.c']]],
  ['sendrequest',['sendRequest',['../connections_8c.html#a3c23eb25de2ae8b5216eb6dd847521c0',1,'sendRequest(long fd, message_t *msg):&#160;connections.c'],['../connections_8h.html#a3c23eb25de2ae8b5216eb6dd847521c0',1,'sendRequest(long fd, message_t *msg):&#160;connections.c']]],
  ['stopallthread',['stopAllThread',['../chatty_8c.html#a03070d47a810d44ac351b8f5fd5000f6',1,'stopAllThread(int segnali, int listener, int nThreadAttivi):&#160;chatty.c'],['../chatty_8h.html#a03070d47a810d44ac351b8f5fd5000f6',1,'stopAllThread(int segnali, int listener, int nThreadAttivi):&#160;chatty.c']]],
  ['stoppool',['stopPool',['../chatty_8c.html#abba8289f04610be41e390483374e8cbe',1,'stopPool(int nThreadAttivi):&#160;chatty.c'],['../chatty_8h.html#abba8289f04610be41e390483374e8cbe',1,'stopPool(int nThreadAttivi):&#160;chatty.c']]]
];

var searchData=
[
  ['unregister_5fop',['unregister_op',['../gestione_richieste_8c.html#a81614c50af29bdf3938aa45aec62d139',1,'unregister_op(long fd, message_t m):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#a81614c50af29bdf3938aa45aec62d139',1,'unregister_op(long fd, message_t m):&#160;gestioneRichieste.c']]],
  ['usrlist_5fop',['usrlist_op',['../gestione_richieste_8c.html#aed4f52e3a3c624d8f7f7fc734289f5c9',1,'usrlist_op(long fd, message_t m, int atomica):&#160;gestioneRichieste.c'],['../gestione_richieste_8h.html#aed4f52e3a3c624d8f7f7fc734289f5c9',1,'usrlist_op(long fd, message_t m, int atomica):&#160;gestioneRichieste.c']]]
];
